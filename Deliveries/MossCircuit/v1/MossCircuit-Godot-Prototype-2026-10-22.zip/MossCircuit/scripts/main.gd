extends Node2D
const Rules = preload("res://scripts/rules.gd")
const Art = preload("res://scripts/art.gd")
var config: Dictionary
var stats: Dictionary
var run_seed := 240102
var rng := RandomNumberGenerator.new()
var loot_rng := RandomNumberGenerator.new()
var map_data: Array = []
var grid_size := Vector2i.ZERO
var ground: Texture2D
var hero: AnimatedSprite2D
var camera: Camera2D
var enemies: Array = []
var bullets: Array = []
var pickups: Array = []
var flashes: Array = []
var player_pos := Vector2.ZERO
var wave := 1
var wave_time := 0.0
var elapsed := 0.0
var spawn_clock := 0.0
var shot_clock := 0.0
var hurt_clock := 0.0
var level := 1
var xp := 0
var kills := 0
var state := "title"
var resume_state := "playing"
var next_enemy_id := 0
var ui: CanvasLayer
var top_label: Label
var detail_label: Label
var hp_bar: ProgressBar
var xp_bar: ProgressBar
var overlay: PanelContainer
var menu: VBoxContainer
var seed_edit: LineEdit
var status_label: Label
var choices: Array = []
var upgrade_pending := 0
var choice_generation := 0
var automation := false

func _ready() -> void:
	config = JSON.parse_string(FileAccess.get_file_as_string("res://data/balance.json"))
	ground = load("res://assets/ground_atlas.png")
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	camera = Camera2D.new()
	add_child(camera)
	camera.position = Vector2(config.arena.width, config.arena.height) * 0.5
	camera.zoom = Vector2.ONE
	hero = Art.actor("res://assets/hero_walk.png", 64.0, 11.0)
	add_child(hero)
	_build_ui()
	grid_size = Rules.grid_dimensions(config.arena)
	map_data = Rules.map_cells(run_seed, grid_size.x, grid_size.y)
	player_pos = camera.position
	hero.position = player_pos
	_title()
	if "--smoke" in OS.get_cmdline_user_args():
		automation = true
		_start_run(run_seed)

func _style(color: Color, border: Color) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = color
	box.border_color = border
	box.set_border_width_all(2)
	box.content_margin_left = 22
	box.content_margin_right = 22
	box.content_margin_top = 16
	box.content_margin_bottom = 16
	return box

func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(root)
	var panel := PanelContainer.new()
	panel.position = Vector2(18, 14)
	panel.size = Vector2(924, 82)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_theme_stylebox_override("panel", _style(Color("111f27"), Color("456454")))
	root.add_child(panel)
	var rows := VBoxContainer.new()
	panel.add_child(rows)
	top_label = Label.new()
	top_label.add_theme_font_size_override("font_size", 20)
	top_label.add_theme_color_override("font_color", Color("e8dca6"))
	rows.add_child(top_label)
	var bars := HBoxContainer.new()
	rows.add_child(bars)
	hp_bar = ProgressBar.new()
	hp_bar.custom_minimum_size = Vector2(255, 12)
	hp_bar.show_percentage = false
	bars.add_child(hp_bar)
	xp_bar = ProgressBar.new()
	xp_bar.custom_minimum_size = Vector2(255, 12)
	xp_bar.show_percentage = false
	bars.add_child(xp_bar)
	detail_label = Label.new()
	detail_label.add_theme_font_size_override("font_size", 14)
	bars.add_child(detail_label)
	status_label = Label.new()
	status_label.position = Vector2(22, 508)
	status_label.add_theme_font_size_override("font_size", 14)
	status_label.add_theme_color_override("font_color", Color("bacbb9"))
	root.add_child(status_label)
	overlay = PanelContainer.new()
	overlay.position = Vector2(160, 110)
	overlay.size = Vector2(640, 330)
	overlay.add_theme_stylebox_override("panel", _style(Color("10232bf2"), Color("d4b56b")))
	root.add_child(overlay)
	menu = VBoxContainer.new()
	menu.add_theme_constant_override("separation", 12)
	overlay.add_child(menu)

func _clear_menu(title: String, subtitle: String) -> void:
	for child in menu.get_children():
		menu.remove_child(child)
		child.queue_free()
	var label := Label.new()
	label.text = title
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 30)
	label.add_theme_color_override("font_color", Color("efd893"))
	menu.add_child(label)
	var sub := Label.new()
	sub.text = subtitle
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_size_override("font_size", 16)
	menu.add_child(sub)
	overlay.show()

func _button(text_value: String, action: Callable) -> Button:
	var button := Button.new()
	button.text = text_value
	button.custom_minimum_size = Vector2(0, 42)
	button.add_theme_font_size_override("font_size", 18)
	button.pressed.connect(action)
	menu.add_child(button)
	return button

func _title() -> void:
	state = "title"
	_clear_menu("MOSS CIRCUIT", "A tiny scavenger. Six waves. One last circuit.")
	seed_edit = LineEdit.new()
	seed_edit.text = str(run_seed)
	seed_edit.placeholder_text = "Map seed (integer)"
	seed_edit.alignment = HORIZONTAL_ALIGNMENT_CENTER
	menu.add_child(seed_edit)
	_button("START SALVAGE", func(): _start_run(int(seed_edit.text) if seed_edit.text.is_valid_int() else run_seed)).grab_focus()
	var hint := Label.new()
	hint.text = "WASD / arrows: move  ·  auto-fire  ·  Space: dash\nEsc: pause  ·  1 / 2 / 3: select upgrade"
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	menu.add_child(hint)

func _start_run(seed_value: int) -> void:
	for e in enemies:
		e.sprite.queue_free()
	enemies.clear()
	bullets.clear()
	pickups.clear()
	flashes.clear()
	run_seed = seed_value
	rng.seed = run_seed
	loot_rng.seed = run_seed ^ 58349
	grid_size = Rules.grid_dimensions(config.arena)
	map_data = Rules.map_cells(run_seed, grid_size.x, grid_size.y)
	stats = config.player.duplicate(true)
	stats.max_hp = stats.hp
	stats.pierce = 0
	stats.dash_cooldown = 0.0
	stats.dash_time = 0.0
	player_pos = Vector2(config.arena.width, config.arena.height) * 0.5
	wave = 1
	wave_time = 0.0
	elapsed = 0.0
	spawn_clock = 0.0
	shot_clock = 0.0
	hurt_clock = 0.0
	level = 1
	xp = 0
	kills = 0
	next_enemy_id = 0
	upgrade_pending = 0
	state = "playing"
	overlay.hide()
	_update_hud()

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			if state == "playing":
				state = "paused"
				_clear_menu("CIRCUIT PAUSED", "Your run is frozen.")
				_button("RESUME", _resume).grab_focus()
				_button("RETURN TO TITLE", _title)
			elif state == "paused": _resume()
		if state == "upgrade" and event.keycode in [KEY_1, KEY_2, KEY_3]:
			_take_upgrade(int(event.keycode - KEY_1), choice_generation)

func _resume() -> void:
	state = "playing"
	overlay.hide()

func _process(delta: float) -> void:
	if state == "playing": _simulate(minf(delta, 0.05))
	hero.speed_scale = 1.0 if state == "playing" else 0.0
	for e in enemies: e.sprite.speed_scale = 1.0 if state == "playing" else 0.0
	hero.position = player_pos.round()
	camera.position = Vector2(clampf(player_pos.x, 480, config.arena.width - 480) if config.arena.width >= 960 else config.arena.width * 0.5, clampf(player_pos.y, 270, config.arena.height - 270) if config.arena.height >= 540 else config.arena.height * 0.5)
	_update_hud()
	queue_redraw()

func _simulate(dt: float) -> void:
	elapsed += dt
	wave_time += dt
	hurt_clock = maxf(0, hurt_clock - dt)
	stats.dash_cooldown = maxf(0, stats.dash_cooldown - dt)
	stats.dash_time = maxf(0, stats.dash_time - dt)
	var direction := Vector2(float(Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT)) - float(Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT)), float(Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN)) - float(Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP))).normalized()
	if automation: direction = Vector2(cos(elapsed * 0.7), sin(elapsed * 0.7))
	if Input.is_physical_key_pressed(KEY_SPACE) and stats.dash_cooldown <= 0 and direction != Vector2.ZERO:
		stats.dash_time = 0.16
		stats.dash_cooldown = 2.5
	player_pos += direction * stats.speed * dt * (3.0 if stats.dash_time > 0 else 1.0)
	player_pos = player_pos.clamp(Vector2(24, 24), Vector2(config.arena.width - 24, config.arena.height - 24))
	if direction != Vector2.ZERO:
		hero.play("walk")
		if direction.x != 0: hero.flip_h = direction.x < 0
	else: hero.play("idle")
	hero.modulate = Color(1, 0.5, 0.45) if hurt_clock > 0.5 else Color.WHITE
	spawn_clock -= dt
	if spawn_clock <= 0:
		_spawn_enemy()
		spawn_clock = maxf(0.13, float(config.waves.spawn_interval) / (1.0 + wave * 0.3))
	shot_clock -= dt
	if shot_clock <= 0 and not enemies.is_empty():
		_shoot()
		shot_clock = stats.fire_interval
	for e in enemies:
		var move: Vector2 = (player_pos - e.pos).normalized()
		e.pos += move * float(e.speed) * dt
		e.sprite.position = e.pos.round()
		e.sprite.flip_h = move.x > 0
		if e.pos.distance_to(player_pos) < 19.0 * float(e.scale) + 9.0 and hurt_clock <= 0 and stats.dash_time <= 0:
			stats.hp -= e.damage
			hurt_clock = 0.75
			if stats.hp <= 0:
				_finish(false)
				return
	for i in range(bullets.size() - 1, -1, -1):
		var b: Dictionary = bullets[i]
		var previous: Vector2 = b.pos
		b.pos += b.velocity * dt
		b.life -= dt
		for e in enemies:
			if e.hp > 0 and not b.hit.has(e.id) and Geometry2D.get_closest_point_to_segment(e.pos, previous, b.pos).distance_to(e.pos) < 16 * float(e.scale):
				e.hp -= b.damage
				b.hit.append(e.id)
				flashes.append({"pos":e.pos, "life":0.14})
				if b.hit.size() > stats.pierce: b.life = -1
				if b.life < 0: break
		if b.life <= 0: bullets.remove_at(i)
	for i in range(enemies.size() - 1, -1, -1):
		var e: Dictionary = enemies[i]
		if e.hp <= 0:
			pickups.append({"pos": e.pos, "xp": e.xp})
			e.sprite.queue_free()
			enemies.remove_at(i)
			kills += 1
	for i in range(pickups.size() - 1, -1, -1):
		var p: Dictionary = pickups[i]
		var distance: float = p.pos.distance_to(player_pos)
		if distance < stats.pickup_radius: p.pos = p.pos.move_toward(player_pos, dt * 260)
		if distance < 14:
			xp += int(p.xp)
			pickups.remove_at(i)
	for i in range(flashes.size() - 1, -1, -1):
		flashes[i].life -= dt
		if flashes[i].life <= 0: flashes.remove_at(i)
	while xp >= Rules.xp_threshold(level):
		xp -= Rules.xp_threshold(level)
		level += 1
		upgrade_pending += 1
	if upgrade_pending > 0:
		_show_upgrades()
		return
	if wave_time >= float(config.waves.duration): _complete_wave()

func _spawn_enemy() -> void:
	if enemies.size() >= int(config.waves.max_enemies): return
	var angle := rng.randf_range(0, TAU)
	var pos := player_pos + Vector2.from_angle(angle) * rng.randf_range(330, 440)
	pos = pos.clamp(Vector2(12, 12), Vector2(config.arena.width - 12, config.arena.height - 12))
	if pos.distance_to(player_pos) < 180: return
	var kind := 0
	if wave >= 2 and rng.randf() < 0.32: kind = 1
	if wave >= 3 and rng.randf() < 0.20: kind = 2
	var data: Dictionary = config.enemies[kind].duplicate(true)
	var sprite := Art.actor("res://assets/beetle_walk.png", 57.0 * float(data.scale), 9.0 + kind)
	sprite.modulate = Color(str(data.color))
	add_child(sprite)
	next_enemy_id += 1
	data.id = next_enemy_id
	data.pos = pos
	data.hp *= 1.0 + (wave - 1) * 0.12
	data.sprite = sprite
	enemies.append(data)

func _shoot() -> void:
	var nearest: Dictionary = enemies[0]
	var distance: float = player_pos.distance_squared_to(nearest.pos)
	for e in enemies:
		var d: float = player_pos.distance_squared_to(e.pos)
		if d < distance:
			distance = d
			nearest = e
	if distance > 500 * 500: return
	var direction: Vector2 = (nearest.pos - player_pos).normalized()
	bullets.append({"pos":player_pos + direction * 16, "velocity":direction * stats.bullet_speed, "life":1.25, "damage":stats.damage, "hit":[]})

func _complete_wave() -> void:
	for p in pickups: xp += int(p.xp)
	pickups.clear()
	for e in enemies: e.sprite.queue_free()
	enemies.clear()
	bullets.clear()
	if wave >= int(config.waves.count):
		_finish(true)
		return
	wave += 1
	wave_time = 0
	stats.hp = minf(stats.max_hp, stats.hp + 15)
	upgrade_pending += 1
	_show_upgrades()

func _show_upgrades() -> void:
	state = "upgrade"
	choice_generation += 1
	choices = Rules.choose_upgrades(config.upgrades, loot_rng)
	_clear_menu("BUILD YOUR CIRCUIT", "Choose one upgrade · combat is paused")
	for i in range(choices.size()):
		var item: Dictionary = choices[i]
		_button("%d   %s  |  %s" % [i + 1, item.name, item.description], _take_upgrade.bind(i, choice_generation))
	menu.get_child(2).grab_focus()
	if automation: call_deferred("_take_upgrade", 0, choice_generation)

func _take_upgrade(index: int, generation: int) -> void:
	if generation != choice_generation or state != "upgrade" or index < 0 or index >= choices.size(): return
	Rules.apply_upgrade(stats, choices[index])
	choices.clear()
	upgrade_pending -= 1
	if upgrade_pending > 0: _show_upgrades()
	else:
		state = "playing"
		overlay.hide()

func _finish(won: bool) -> void:
	state = "won" if won else "dead"
	stats.hp = maxf(0, stats.hp)
	_clear_menu("CIRCUIT RESTORED" if won else "SIGNAL LOST", "Wave %d · Level %d · %d salvaged · Seed %d" % [wave, level, kills, run_seed])
	_button("RETRY SAME SEED", func(): _start_run(run_seed)).grab_focus()
	_button("NEW SEED", func(): _start_run(run_seed + 1))
	_button("TITLE", _title)

func _update_hud() -> void:
	top_label.text = "MOSS CIRCUIT     /     WAVE %d / %d     /     %02d:%02d" % [wave, int(config.waves.count), int(elapsed) / 60, int(elapsed) % 60]
	if stats.is_empty(): return
	hp_bar.max_value = stats.max_hp
	hp_bar.value = stats.hp
	xp_bar.max_value = Rules.xp_threshold(level)
	xp_bar.value = xp
	detail_label.text = " HP %d/%d   LV %d   KILLS %d" % [stats.hp, stats.max_hp, level, kills]
	status_label.text = "WASD / ARROWS   ·   AUTO FIRE   ·   SPACE DASH %s   ·   ESC PAUSE    |    SEED %d" % ["READY" if stats.dash_cooldown <= 0 else "%.1fs" % stats.dash_cooldown, run_seed]

func _draw() -> void:
	if ground == null: return
	var tile: int = config.arena.tile_size
	for y in range(grid_size.y):
		for x in range(grid_size.x):
			var index: int = map_data[y * grid_size.x + x]
			var rect := Rect2(x * tile, y * tile, minf(tile, config.arena.width - x * tile), minf(tile, config.arena.height - y * tile))
			draw_texture_rect_region(ground, rect, Art.region(ground, index), Color(0.65, 0.75, 0.72))
			# Deliberate modular floor joints disguise non-identical generated edges.
			draw_rect(rect, Color(0.03, 0.08, 0.09, 0.28), false, 1.0)
	draw_rect(Rect2(0, 0, config.arena.width, config.arena.height), Color("a0b77c"), false, 4)
	for p in pickups:
		draw_rect(Rect2(p.pos - Vector2(3, 3), Vector2(6, 6)), Color("86e6c1"))
	for b in bullets:
		draw_rect(Rect2(b.pos - Vector2(3, 2), Vector2(6, 4)), Color("ffe1a3"))
	for f in flashes:
		draw_circle(f.pos, 8, Color("f4d692"), false, 2)
	if state == "playing" and stats.dash_time > 0:
		draw_circle(player_pos, 24, Color("b6f2df"), false, 2)
