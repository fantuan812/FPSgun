extends RefCounted
## Pure run rules; configuration owns balance, presentation owns no damage logic.
static func xp_threshold(level: int) -> int:
	return 12 + (level - 1) * 9

static func apply_upgrade(stats: Dictionary, upgrade: Dictionary) -> void:
	match str(upgrade.id):
		"damage": stats.damage *= float(upgrade.value)
		"speed": stats.speed = minf(stats.speed * float(upgrade.value), 300.0)
		"haste": stats.fire_interval = maxf(0.09, stats.fire_interval * float(upgrade.value))
		"health":
			stats.max_hp += float(upgrade.value)
			stats.hp = minf(stats.max_hp, stats.hp + 30.0)
		"magnet": stats.pickup_radius += float(upgrade.value)
		"pierce": stats.pierce = mini(5, int(stats.pierce) + 1)

static func choose_upgrades(pool: Array, rng: RandomNumberGenerator) -> Array:
	var ids: Array = range(pool.size())
	for i in range(ids.size() - 1, 0, -1):
		var j: int = rng.randi_range(0, i)
		var old: Variant = ids[i]
		ids[i] = ids[j]
		ids[j] = old
	var result: Array = []
	for i in range(mini(3, ids.size())):
		result.append(pool[ids[i]].duplicate(true))
	return result

static func map_cells(seed_value: int, columns: int, rows: int) -> Array:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	var cells: Array = []
	for y in range(rows):
		for x in range(columns):
			# All nine tiles are walkable. No random obstacle can disconnect the map.
			cells.append(rng.randi_range(0, 8) if rng.randf() < 0.38 else 8)
	return cells

static func grid_dimensions(arena: Dictionary) -> Vector2i:
	return Vector2i(ceili(float(arena.width) / float(arena.tile_size)), ceili(float(arena.height) / float(arena.tile_size)))
